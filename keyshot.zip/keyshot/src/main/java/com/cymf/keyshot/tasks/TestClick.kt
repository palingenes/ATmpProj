package com.cymf.keyshot.tasks

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.cymf.keyshot.App
import com.cymf.keyshot.utils.AssistsCore
import com.cymf.keyshot.utils.CoroutineWrapper
import com.cymf.keyshot.utils.YLLogger
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.delay
import kotlin.random.Random

import com.cymf.keyshot.utils.AssistsCore.getBoundsInScreen
import com.cymf.keyshot.utils.DisplayUtil
import com.cymf.keyshot.utils.ShellSwipeUtil.clickInBounds

object TestClick {

    fun click() {
//        randomClick()

//        CoroutineWrapper.launch {
//            delay(300)
//            "${(TaskPollingManager.getCurrTask()?.taskID ?: "NO_TASK")}_${System.currentTimeMillis()}".let { fileName ->
//                AssistsService.instance?.rootInActiveWindow.printNodeInfoJSON()?.apply {
//                    YLLogger.writeToFile("$fileName.txt", GsonUtils.toJson(this))
//                }
//                YLLogger.screenshot("$fileName.png")
//            }
//        }

//        CoroutineWrapper.launch {
//            val duration = 10_000L
//            YLLogger.e("printNodeInfo======== $duration ms")
//            delay(duration)
//            val nodes = WindowDumpAnalyzer.analyzeWindowDump()
//            if (nodes.isEmpty()) {
//                YLLogger.e("node is empty😭")
//                return@launch
//            }
//            nodes.printNodeTree()
//        }

//        CoroutineWrapper.launch {
//            val (data, error) = NetworkClient.get(SPUtil.PHONE_ID)
//            LogUtils.e(data)
//        }

//        NetworkClient.complete<TaskBean>("{}") { data, error ->
//            YLLogger.e(data.toString(), error)
//        }

//        CoroutineWrapper.launch {
//
//            delay(10_000)
//            YLLogger.e("printNodeInfo========")
//            AssistsService.instance?.rootInActiveWindow.printNodeInfo()
//        }

    }

    fun forceStop() {
        CoroutineWrapper.launch {
//            TaskPollingManager.reportTaskComp(false)
            delay(1000)
            Shell.cmd("am force-stop ${App.context.packageName}").exec()
//            Process.killProcess(Process.myPid())
//            exitProcess(0)
        }
    }

    fun forcePause() {
        CoroutineWrapper.launch {
//            TaskPollingManager.setIsPauseGetTask(true)
//            TaskPollingManager.reportTaskComp(false)
//            TaskPollingManager.stopPolling()
            delay(1000)
        }
    }

    fun forceStart() {
        CoroutineWrapper.launch {
//            TaskPollingManager.setIsPauseGetTask(false)
//            delay(1000)
//            TaskPollingManager.startPolling()
        }
    }

    fun AccessibilityNodeInfo?.printNodeInfo(
        builder: StringBuilder? = null,
        prefix: String = "",
        isLast: Boolean = false
    ) {
        val node = this ?: return
        if (!node.isEnabled) return

        val sb = StringBuilder()

        sb.append("className = ${node.className}")
        if (node.className == "android.webkit.WebView") {
            sb.append(" -> ").append("child = ${node.childCount} ")
        }
        sb.append(" -> ").append("text = ${node.text} ")
        sb.append(" -> ").append("id = ${node.viewIdResourceName}")
        sb.append(" -> ").append("desc = ${node.contentDescription}")
        sb.append(" -> ").append("isClickable = ${node.isClickable}")
        sb.append(" -> ").append("isEnabled = ${node.isEnabled}")
        sb.append(" -> ").append("${node.getBoundsInScreen()}")

        val marker = if (isLast) """\--- """ else "+--- "
        val currentPrefix = "$prefix$marker"
        YLLogger.log2(currentPrefix + sb.toString())
        builder?.append(currentPrefix)?.append(sb)?.append("\n")

        val size = node.childCount
        if (size > 0) {
            val childPrefix = prefix + if (isLast) "  " else "|  "
            val lastChildIndex = size - 1
            for (index in 0 until size) {
                val isLastChild = index == lastChildIndex
                node.getChild(index)?.printNodeInfo(builder, childPrefix, isLastChild)
            }
        }
    }

    fun AccessibilityNodeInfo?.printNodeInfoJSON(
        prefix: String = "",
        isLast: Boolean = false
    ): NodeWrapper? {
        val node = this ?: return null

//        val sb = StringBuilder()
//
//        sb.append("className = ${node.className}")
//        if (node.className == "android.webkit.WebView") {
//            sb.append(" -> ").append("child = ${node.childCount} ")
//        }
//        sb.append(" -> ").append("text = ${node.text} ")
//        sb.append(" -> ").append("id = ${node.viewIdResourceName}")
//        sb.append(" -> ").append("desc = ${node.contentDescription}")
//        sb.append(" -> ").append("isClickable = ${node.isClickable}")
//        sb.append(" -> ").append("isEnabled = ${node.isEnabled}")
//        sb.append(" -> ").append("${node.getBoundsInScreen()}")
//
//        val marker = if (isLast) """\--- """ else "+--- "
//        val currentPrefix = "$prefix$marker"
//        builder?.append(currentPrefix)?.append(sb)?.append("\n")

        val size = node.childCount
        val childrenWrapper = mutableListOf<NodeWrapper?>()
        if (size > 0) {
            val childPrefix = prefix + if (isLast) "  " else "|  "
            val lastChildIndex = size - 1
            for (index in 0 until size) {
                val isLastChild = index == lastChildIndex
                node.getChild(index)?.printNodeInfoJSON(childPrefix, isLastChild).apply {
                    childrenWrapper.add(this)
                }
            }
        }
        return NodeWrapper(
            node.className?.toString(),
            node.text?.toString(),
            node.viewIdResourceName,
            node.contentDescription?.toString(),
            node.isClickable,
            node.isEnabled,
            node.getBoundsInScreen(),
            childrenWrapper
        )
    }

    private fun randomClick() {
        CoroutineWrapper.launch {
            val randomRect = generateRandomRect()
            YLLogger.e(randomRect.toString())
            randomRect.clickInBounds()
            YLLogger.e("-------------------------------\n")
            AssistsCore.gestureClick(randomRect, Random.nextInt(200, 501).toLong())
        }
    }

    fun generateRandomRect(
        minWidth: Int = 50,
        minHeight: Int = 50,
        paddingPercentX: Float = 0.1f, // 左右各 10%
        paddingPercentY: Float = 0.2f  // 上下各 20%
    ): Rect {
        val screenWidth = DisplayUtil.widthPixels()
        val screenHeight = DisplayUtil.heightPixels()

        // 计算可用区域
        val leftBound = (screenWidth * paddingPercentX).toInt()
        val rightBound = screenWidth - leftBound
        val topBound = (screenHeight * paddingPercentY).toInt()
        val bottomBound = screenHeight - topBound

        // 可用宽高
        val effectiveMaxWidth = rightBound - leftBound
        val effectiveMaxHeight = bottomBound - topBound

        // 确保最小尺寸不超过有效区域
        val width = Random.nextInt(minWidth, effectiveMaxWidth.coerceAtLeast(minWidth + 1))
        val height = Random.nextInt(minHeight, effectiveMaxHeight.coerceAtLeast(minHeight + 1))

        // 随机位置（在限定区域内）
        val left = Random.nextInt(leftBound, rightBound - width)
        val top = Random.nextInt(topBound, bottomBound - height)

        val right = left + width
        val bottom = top + height

        return Rect(left, top, right, bottom)
    }


}

data class NodeWrapper(
    val className: String?,
    val text: String?,
    val id: String?,
    val desc: String?,
    val clickable: Boolean,
    val enabled: Boolean,
    val bounds: Rect,
    val children: List<NodeWrapper?>
)