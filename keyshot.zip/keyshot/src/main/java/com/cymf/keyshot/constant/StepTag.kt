package com.cymf.keyshot.constant

/**
 * @time 2025/04/10 10:09
 * @version V1.0.1
 * @author wzy
 * </>
 * @desc 步骤名称，不够的再往上加
 */
object StepTag {

    const val STEP_EXC = 10086 //  步骤异常：一般为逻辑异常
    const val ERROR_HANDLER_TAG = 1008610 //  全局异常信息拦截标识
    const val AD_STEP_TAG = 1008611 //  广告拦截后的标识，统一处理广告

    /**
     * 全局静态常量步骤标识1~200，不够自己定义
     */
    const val STEP_1 = 1
    const val STEP_2 = 2
    const val STEP_3 = 3
    const val STEP_4 = 4
    const val STEP_5 = 5
    const val STEP_6 = 6
    const val STEP_7 = 7
    const val STEP_8 = 8
    const val STEP_9 = 9

    /** */
    const val STEP_10 = 10
    const val STEP_11 = 11
    const val STEP_12 = 12
    const val STEP_13 = 13
    const val STEP_14 = 14
    const val STEP_15 = 15
    const val STEP_16 = 16
    const val STEP_17 = 17
    const val STEP_18 = 18
    const val STEP_19 = 19

    /** */
    const val STEP_20 = 20
    const val STEP_21 = 21
    const val STEP_22 = 22
    const val STEP_23 = 23
    const val STEP_24 = 24
    const val STEP_25 = 25
    const val STEP_26 = 26
    const val STEP_27 = 27
    const val STEP_28 = 28
    const val STEP_29 = 29

    /** */
    const val STEP_30 = 30
    const val STEP_31 = 31
    const val STEP_32 = 32
    const val STEP_33 = 33
    const val STEP_34 = 34
    const val STEP_35 = 35
    const val STEP_36 = 36
    const val STEP_37 = 37
    const val STEP_38 = 38
    const val STEP_39 = 39

    /** */
    const val STEP_40 = 40
    const val STEP_41 = 41
    const val STEP_42 = 42
    const val STEP_43 = 43
    const val STEP_44 = 44
    const val STEP_45 = 45
    const val STEP_46 = 46
    const val STEP_47 = 47
    const val STEP_48 = 48
    const val STEP_49 = 49

    /** */
    const val STEP_50 = 50
    const val STEP_51 = 51
    const val STEP_52 = 52
    const val STEP_53 = 53
    const val STEP_54 = 54
    const val STEP_55 = 55
    const val STEP_56 = 56
    const val STEP_57 = 57
    const val STEP_58 = 58
    const val STEP_59 = 59

    /** */
    const val STEP_60 = 60
    const val STEP_61 = 61
    const val STEP_62 = 62
    const val STEP_63 = 63
    const val STEP_64 = 64
    const val STEP_65 = 65
    const val STEP_66 = 66
    const val STEP_67 = 67
    const val STEP_68 = 68
    const val STEP_69 = 69

    /** */
    const val STEP_70 = 70
    const val STEP_71 = 71
    const val STEP_72 = 72
    const val STEP_73 = 73
    const val STEP_74 = 74
    const val STEP_75 = 75
    const val STEP_76 = 76
    const val STEP_77 = 77
    const val STEP_78 = 78
    const val STEP_79 = 79

    /** */
    const val STEP_80 = 80
    const val STEP_81 = 81
    const val STEP_82 = 82
    const val STEP_83 = 83
    const val STEP_84 = 84
    const val STEP_85 = 85
    const val STEP_86 = 86
    const val STEP_87 = 87
    const val STEP_88 = 88
    const val STEP_89 = 89

    /** */
    const val STEP_90 = 90
    const val STEP_91 = 91
    const val STEP_92 = 92
    const val STEP_93 = 93
    const val STEP_94 = 94
    const val STEP_95 = 95
    const val STEP_96 = 96
    const val STEP_97 = 97
    const val STEP_98 = 98
    const val STEP_99 = 99

    /** */
    const val STEP_100 = 100
    const val STEP_101 = 101
    const val STEP_102 = 102
    const val STEP_103 = 103
    const val STEP_104 = 104
    const val STEP_105 = 105
    const val STEP_106 = 106
    const val STEP_107 = 107
    const val STEP_108 = 108
    const val STEP_109 = 109

    /** */
    const val STEP_110 = 110
    const val STEP_111 = 111
    const val STEP_112 = 112
    const val STEP_113 = 113
    const val STEP_114 = 114
    const val STEP_115 = 115
    const val STEP_116 = 116
    const val STEP_117 = 117
    const val STEP_118 = 118
    const val STEP_119 = 119

    /** */
    const val STEP_120 = 120
    const val STEP_121 = 121
    const val STEP_122 = 122
    const val STEP_123 = 123
    const val STEP_124 = 124
    const val STEP_125 = 125
    const val STEP_126 = 126
    const val STEP_127 = 127
    const val STEP_128 = 128
    const val STEP_129 = 129

    /** */
    const val STEP_130 = 130
    const val STEP_131 = 131
    const val STEP_132 = 132
    const val STEP_133 = 133
    const val STEP_134 = 134
    const val STEP_135 = 135
    const val STEP_136 = 136
    const val STEP_137 = 137
    const val STEP_138 = 138
    const val STEP_139 = 139

    /** */
    const val STEP_140 = 140
    const val STEP_141 = 141
    const val STEP_142 = 142
    const val STEP_143 = 143
    const val STEP_144 = 144
    const val STEP_145 = 145
    const val STEP_146 = 146
    const val STEP_147 = 147
    const val STEP_148 = 148
    const val STEP_149 = 149

    /** */
    const val STEP_150 = 150
    const val STEP_151 = 151
    const val STEP_152 = 152
    const val STEP_153 = 153
    const val STEP_154 = 154
    const val STEP_155 = 155
    const val STEP_156 = 156
    const val STEP_157 = 157
    const val STEP_158 = 158
    const val STEP_159 = 159

    /** */
    const val STEP_160 = 160
    const val STEP_161 = 161
    const val STEP_162 = 162
    const val STEP_163 = 163
    const val STEP_164 = 164
    const val STEP_165 = 165
    const val STEP_166 = 166
    const val STEP_167 = 167
    const val STEP_168 = 168
    const val STEP_169 = 169

    /** */
    const val STEP_170 = 170
    const val STEP_171 = 171
    const val STEP_172 = 172
    const val STEP_173 = 173
    const val STEP_174 = 174
    const val STEP_175 = 175
    const val STEP_176 = 176
    const val STEP_177 = 177
    const val STEP_178 = 178
    const val STEP_179 = 179

    /** */
    const val STEP_180 = 180
    const val STEP_181 = 181
    const val STEP_182 = 182
    const val STEP_183 = 183
    const val STEP_184 = 184
    const val STEP_185 = 185
    const val STEP_186 = 186
    const val STEP_187 = 187
    const val STEP_188 = 188
    const val STEP_189 = 189

    /** */
    const val STEP_190 = 190
    const val STEP_191 = 191
    const val STEP_192 = 192
    const val STEP_193 = 193
    const val STEP_194 = 194
    const val STEP_195 = 195
    const val STEP_196 = 196
    const val STEP_197 = 197
    const val STEP_198 = 198
    const val STEP_199 = 199
    const val STEP_200 = 200
}