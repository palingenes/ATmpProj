package com.google.android.accessibility.selecttospeak

import com.cymf.autogame.service.AssistsService


/**
 * 使用这个无障碍服务可以解决一些应用混淆节点的问题
 */
class SelectToSpeakService: AssistsService()